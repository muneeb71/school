document.addEventListener("DOMContentLoaded", function () {
    $(".date-pick").datepicker({
        format: "dd-mm-yyyy",
    });
});